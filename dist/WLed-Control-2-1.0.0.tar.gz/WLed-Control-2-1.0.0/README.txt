This is a very simple WLed controller

# Control lights
to turn it on or off or toggle
use onOff()
choses are ["on", "off", "toggle"]

# Control brightness
to get the brightness

use get_bri()

to set the brightness
use set_bri() with a value between 0 and 255

# Control color
to get the color
use get_col() you will get the RGB values

to set the color
use set_col() with the RGB values or a color name

# Control effect
to get the effect
use get_fx()

to set the effect
use set_fx() with a value between 0 and 101 or the name of the effect

# Control speed
to set speed
use set_speed() with a value between 0 and 255
