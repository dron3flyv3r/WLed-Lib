This is a very simple WLed controller
